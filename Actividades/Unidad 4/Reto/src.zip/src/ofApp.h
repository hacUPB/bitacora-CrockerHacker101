#pragma once

#include "ofMain.h"
#include <queue>
#include <stack>

class AttractorParticle {
public:
	ofVec2f pos;
	ofVec2f vel;
	bool arrived = false;

	AttractorParticle(ofVec2f startPos) {
		pos = startPos;
		vel.set(0, 0);
	}

	void update(const ofVec2f & target) {
		if (arrived) return;
		ofVec2f dir = target - pos;
		float dist = dir.length();
		if (dist < 5.0f) {
			arrived = true;
		} else {
			dir.normalize();
			vel += dir * 0.5;
			vel *= 0.9;
			pos += vel;
		}
	}

	void draw() {
		if (!arrived)
			ofDrawCircle(pos, 5);
	}
};

class FloatingParticle {
public:
	ofVec2f pos;
	float speed;

	FloatingParticle(ofVec2f startPos) {
		pos = startPos;
		speed = ofRandom(1.0, 2.0);
	}

	void update() {
		pos.y -= speed;
	}

	void draw(float radius) {
		ofSetColor(255);
		ofDrawCircle(pos, radius);
	}

	bool isOffScreen() {
		return pos.y < -10;
	}
};

class BouncingParticle {
public:
	ofVec2f pos;
	ofVec2f vel;
	ofColor color;
	float radius;
	float lifeTime;
	float maxLifeTime;

	BouncingParticle(ofVec2f startPos, ofColor c) {
		pos = startPos;
		color = c;
		radius = 7.0f;
		vel.set(ofRandom(-5, 5), ofRandom(-5, 5));
		lifeTime = 0;
		maxLifeTime = 5.0f;
	}

	void update(float dt, int screenWidth, int screenHeight) {
		pos += vel;
		if (pos.x < radius) {
			pos.x = radius;
			vel.x *= -1;
		}
		if (pos.x > screenWidth - radius) {
			pos.x = screenWidth - radius;
			vel.x *= -1;
		}
		if (pos.y < radius) {
			pos.y = radius;
			vel.y *= -1;
		}
		if (pos.y > screenHeight - radius) {
			pos.y = screenHeight - radius;
			vel.y *= -1;
		}
		lifeTime += dt;
	}

	void draw() {
		ofSetColor(color);
		ofDrawCircle(pos, radius);
	}

	bool isDead() {
		return lifeTime >= maxLifeTime;
	}
};

class ofApp : public ofBaseApp {
public:
	void setup();
	void update();
	void draw();
	void keyPressed(int key);
	void exit(); 

	ofVec2f mousePos;
	float cursorRadius;
	float maxCursorRadiusModificable;

	std::stack<AttractorParticle *> particlesStack; 
	std::queue<FloatingParticle *> ambientParticlesQueue; 
	std::vector<BouncingParticle> bouncingParticles; 

	string instructions;

	float ambientParticleRadius;
	float ambientParticleRadiusMin;
	float ambientParticleRadiusMax;
};
