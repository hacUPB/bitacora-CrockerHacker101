#include "ofApp.h"

void ofApp::setup() {
	ofBackground(0);
	ofSetFrameRate(60);
	cursorRadius = 10.0f;
	maxCursorRadiusModificable = 400.0f;

	ambientParticleRadius = 3.0f;
	ambientParticleRadiusMin = 1.0f;
	ambientParticleRadiusMax = 10.0f;

	instructions = "Presiona 'E' para emitir energ�a\nPresiona 'ESPACIO' para reiniciar y explotar la bola\nFlecha ARRIBA/ABAJO para cambiar tama�o de las particulas blancas";
}

void ofApp::update() {
	float dt = 1.0f / 60.0f;

	mousePos.set(ofGetMouseX(), ofGetMouseY());

	for (auto & p : particles) {
		if (!p.arrived) {
			p.update(mousePos);
			if (p.arrived && cursorRadius < maxCursorRadiusModificable) {
				cursorRadius += 0.7f;
				if (cursorRadius > maxCursorRadiusModificable) {
					cursorRadius = maxCursorRadiusModificable;
				}
			}
		}
	}

	particles.erase(
		std::remove_if(particles.begin(), particles.end(), [](AttractorParticle & p) {
			return p.arrived;
		}),
		particles.end());

	for (auto & ap : ambientParticles) {
		ap.update();
	}

	ambientParticles.erase(
		std::remove_if(ambientParticles.begin(), ambientParticles.end(), [](FloatingParticle & ap) {
			return ap.isOffScreen();
		}),
		ambientParticles.end());

	for (auto & bp : bouncingParticles) {
		bp.update(dt, ofGetWidth(), ofGetHeight());
	}

	bouncingParticles.erase(
		std::remove_if(bouncingParticles.begin(), bouncingParticles.end(), [](BouncingParticle & bp) {
			return bp.isDead();
		}),
		bouncingParticles.end());
}

void ofApp::draw() {
	for (auto & ap : ambientParticles) {
		ap.draw(ambientParticleRadius);
	}

	ofSetColor(0, 150, 255);
	for (auto & p : particles) {
		p.draw();
	}

	for (auto & bp : bouncingParticles) {
		bp.draw();
	}

	if (cursorRadius >= maxCursorRadiusModificable) {
		ofSetColor(255, 255, 0);
	} else {
		ofSetColor(0, 150, 255);
	}
	ofDrawCircle(mousePos, cursorRadius);

	ofSetColor(255);
	ofDrawBitmapString(instructions, 15, 20);
}

void ofApp::keyPressed(int key) {
	if (key == 'e' || key == 'E') {
		for (int i = 0; i < 10; i++) {
			float x = ofRandomWidth();
			float y = ofGetHeight() + ofRandom(10, 50);

			particles.emplace_back(ofVec2f(x, y));
			ambientParticles.emplace_back(ofVec2f(x, y));
		}
	}

	if (key == ' ') {
		ofColor bolaColor;
		if (cursorRadius >= maxCursorRadiusModificable) {
			bolaColor = ofColor(255, 255, 0);
		} else {
			bolaColor = ofColor(0, 150, 255);
		}

		int numBolitas = 30;
		for (int i = 0; i < numBolitas; i++) {
			bouncingParticles.emplace_back(mousePos, bolaColor);
		}

		particles.clear();
		ambientParticles.clear();
		cursorRadius = 10.0f;
	}

	if (key == OF_KEY_UP) {
		ambientParticleRadius += 1.0f;
		if (ambientParticleRadius > ambientParticleRadiusMax) {
			ambientParticleRadius = ambientParticleRadiusMax;
		}
	}

	if (key == OF_KEY_DOWN) {
		ambientParticleRadius -= 1.0f;
		if (ambientParticleRadius < ambientParticleRadiusMin) {
			ambientParticleRadius = ambientParticleRadiusMin;
		}
	}
}
