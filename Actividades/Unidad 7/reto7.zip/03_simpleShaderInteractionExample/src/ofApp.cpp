#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup() {
	if (ofIsGLProgrammableRenderer()) {
		shader.load("shadersGL3/shader");
	} else {
		shader.load("shadersGL2/shader");
	}

	ofDisableArbTex(); // importante para usar coords normalizadas (0�1)
	chad.load("chad.jpg"); // <-- carga la imagen

	int planeWidth = ofGetWidth();
	int planeHeight = ofGetHeight();
	int planeGridSize = 20;
	int planeColumns = planeWidth / planeGridSize;
	int planeRows = planeHeight / planeGridSize;

	plane.set(planeWidth, planeHeight, planeColumns, planeRows, OF_PRIMITIVE_TRIANGLES);
}

//--------------------------------------------------------------
void ofApp::update() { }

//--------------------------------------------------------------
void ofApp::draw() {
	shader.begin();


	shader.setUniformTexture("tex0", chad.getTexture(), 0);

	float cx = ofGetWidth() / 2.0;
	float cy = ofGetHeight() / 2.0;

	float mx = mouseX - cx;
	float my = mouseY - cy;

	shader.setUniform1f("mouseRange", 150);
	shader.setUniform2f("mousePos", mx, my);

	float percentX = mouseX / (float)ofGetWidth();
	percentX = ofClamp(percentX, 0, 1);
	ofFloatColor colorLeft = ofColor::yellow;
	ofFloatColor colorRight = ofColor::black;
	ofFloatColor colorMix = colorLeft.getLerped(colorRight, percentX);

	float mouseColor[4] = { colorMix.r, colorMix.g, colorMix.b, colorMix.a };
	shader.setUniform4fv("mouseColor", mouseColor);

	ofTranslate(cx, cy);

	chad.getTexture().bind();
	plane.draw();
	chad.getTexture().unbind();

	shader.end();
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key) { }
void ofApp::keyReleased(int key) { }
void ofApp::mouseMoved(int x, int y) { }
void ofApp::mouseDragged(int x, int y, int button) { }
void ofApp::mousePressed(int x, int y, int button) { }
void ofApp::mouseReleased(int x, int y, int button) { }
void ofApp::windowResized(int w, int h) { }
void ofApp::gotMessage(ofMessage msg) { }
void ofApp::dragEvent(ofDragInfo dragInfo) { }
