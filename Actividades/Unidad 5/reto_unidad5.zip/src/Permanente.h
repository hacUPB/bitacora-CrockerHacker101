#pragma once
#include "Particulas.h"
#include "Particulasaltarina.h"

class ParticlePermanent : public Particle {
public:
	bool exploded;

	ParticlePermanent(ofVec2f pos)
		: Particle(pos) {
		exploded = false;
	}

	void update(float dt) override {
		if (!exploded) {
			size += sin(ofGetElapsedTimef()) * 0.1;
		}
	}

	void draw() override {
		if (!exploded) {
			ofSetColor(color);
			if (shapeType == 0)
				ofDrawCircle(position, size);
			else if (shapeType == 1)
				ofDrawRectangle(position.x - size / 2, position.y - size / 2, size, size);
			else
				ofDrawTriangle(position.x, position.y - size,
					position.x - size, position.y + size,
					position.x + size, position.y + size);
		}
	}

	vector<Particle *> explode() {
		vector<Particle *> fragments;
		if (!exploded) {
			exploded = true;
			alive = false;
			int numFragments = ofRandom(20, 40);
			for (int i = 0; i < numFragments; i++) {
				fragments.push_back(new ParticleBounce(position));
			}
		}
		return fragments;
	}
};
