#include "ofApp.h"

void ofApp::setup() {
	ofBackground(0);
	ofSetFrameRate(60);
}

void ofApp::update() {
	float dt = 1.0 / 60.0;
	for (int i = particles.size() - 1; i >= 0; i--) {
		particles[i]->update(dt);
		if (!particles[i]->alive) {
			delete particles[i];
			particles.erase(particles.begin() + i);
		}
	}

	mouseBall.set(ofGetMouseX(), ofGetMouseY());
}

void ofApp::draw() {
	ofSetColor(255, 100, 200);
	ofDrawCircle(mouseBall, 15);

	for (auto & p : particles) {
		p->draw();
	}

	ofSetColor(255);
	string help = "";
	help += "Controles:\n";
	help += "g - Figura transitoria (expande y desaparece)\n";
	help += "h - Figura permanente (se queda)\n";
	help += "e - Explosiona las permanentes en particulas\n";
	help += "SPACE - Limpiar pantalla\n";

	ofDrawBitmapString(help, ofGetWidth() - 320, 20);
}


void ofApp::keyPressed(int key) {
	if (key == 'g') {
		particles.push_back(new ParticleTransient(mouseBall));
	} else if (key == 'h') {
		particles.push_back(new ParticlePermanent(mouseBall));
	} else if (key == 'e') {
		vector<Particle *> newParticles;
		for (int i = particles.size() - 1; i >= 0; i--) {
			ParticlePermanent * p = dynamic_cast<ParticlePermanent *>(particles[i]);
			if (p && !p->exploded) {
				vector<Particle *> frags = p->explode();
				newParticles.insert(newParticles.end(), frags.begin(), frags.end());
			}
		}
		particles.insert(particles.end(), newParticles.begin(), newParticles.end());
	} else if (key == ' ') {
		for (auto & p : particles) {
			delete p;
		}
		particles.clear();
	}
}


void ofApp::exit() {
	for (auto & p : particles) {
		delete p;
	}
	particles.clear();
}
