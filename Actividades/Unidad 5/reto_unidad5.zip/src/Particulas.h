#pragma once
#include "ofMain.h"

class Particle {
protected:
	ofVec2f position;
	ofColor color;
	float size;
	int shapeType;

public:
	bool alive;

	Particle(ofVec2f pos) {
		position = pos;
		size = ofRandom(20, 50);
		color = ofColor::fromHsb(ofRandom(255), 200, 255);
		alive = true;
		shapeType = (int)ofRandom(3);
	}

	virtual void update(float dt) = 0;
	virtual void draw() = 0;

	virtual ~Particle() { }
};
