﻿#include "ofApp.h"
#include <cmath>

// ---------- ESTADOS GENÉRICOS ----------
class BuildingState : public State {
protected:
	std::vector<std::shared_ptr<Building>> * buildings;
	std::vector<std::shared_ptr<Car>> * cars;
	Subject * subject;
	ofColor baseColor1, baseColor2;
	float quakeForce = 0;
	float collapseTime = 0;
	std::string name;

public:
	BuildingState(std::vector<std::shared_ptr<Building>> * b,
		std::vector<std::shared_ptr<Car>> * c,
		Subject * s,
		ofColor c1, ofColor c2, float force, float collapse, std::string n)
		: buildings(b)
		, cars(c)
		, subject(s)
		, baseColor1(c1)
		, baseColor2(c2)
		, quakeForce(force)
		, collapseTime(collapse)
		, name(std::move(n)) { }

	void enter() override {
		for (auto & b : *buildings)
			b->color = baseColor1.getLerped(baseColor2, ofRandom(1.0));

		for (auto & c : *cars)
			c->color = baseColor1.getLerped(baseColor2, ofRandom(1.0));
	}

	void update(float elapsedTime, bool shaking) override {
		for (auto & b : *buildings) {
			b->update();
			if (shaking && !b->fallen)
				b->pos.x = b->baseX + sin(ofGetElapsedTimef() * (8 + quakeForce) + b->pos.y * 0.01) * quakeForce;
			else
				b->pos.x = b->baseX;
		}

		for (auto & c : *cars) {
			c->update();

			if (shaking && !c->crushed) {
				c->pos.x += sin(ofGetElapsedTimef() * (10 + quakeForce));
			}

			if (c->crushed) {
				if (name == "ay mano") {
					c->scaleY = 0.75f; // aplastar 1/4
				} else if (name == "TERREMOTOOOOO!!!") {
					c->scaleY = 0.5f; // aplastar a la mitad
				} else {
					c->scaleY = 1.0f;
				}
			} else {
				c->scaleY = 1.0f;
			}
		}

		if (shaking && collapseTime > 0 && elapsedTime > collapseTime)
			subject->notify("collapse");
	}

	void draw() override {
		for (const auto & b : *buildings)
			b->draw();

		for (const auto & c : *cars)
			c->draw();
	}

	std::string getName() const override { return name; }
	float getCollapseTime() const override { return collapseTime; }
};

// ---------- APP IMPLEMENTACIÓN ----------
void ofApp::setup() {
	ofSetFrameRate(60);
	ofBackground(0);

	buildings.clear();
	cars.clear();

	float baseY = ofGetHeight();
	float buildingSpacing = 60; // distancia fija entre edificios
	float carSpacing = 100;

	// Crear edificios
	for (int i = 0; i < 20; ++i) {
		float w = 30;
		float h = 150 + (i % 5) * 30;
		float x = 50 + i * buildingSpacing;
		auto b = BuildingFactory::createBuilding({ x, baseY }, w, h, ofColor::blue);
		addObserver(b.get());
		buildings.push_back(b);
	}

	// Crear carros para el estado 1, 2 y 3
	for (int i = 0; i < 10; ++i) {
		float r = 12;
		float x = 100 + i * carSpacing;
		float y = baseY - 10; // un poco arriba del suelo
		auto c = CarFactory::createCar({ x, y }, r, ofColor::red);
		addObserver(c.get());
		cars.push_back(c);
	}

	currentState = std::make_shared<BuildingState>(&buildings, &cars, this,
		ofColor(100, 100, 255), ofColor(180, 0, 255), 0.2, 0, "calma");
	currentState->enter();
	stateStartTime = ofGetElapsedTimef();
}

void ofApp::update() {
	currentState->update(ofGetElapsedTimef() - stateStartTime, shaking);
}

void ofApp::draw() {
	currentState->draw();
	ofSetColor(255);
	ofDrawBitmapStringHighlight("1: calma | 2: ay mano | 3: TERREMOTOOOOOO!!!", 20, 20);
	ofDrawBitmapStringHighlight("S: temblor| P: parar | SPACE: reconstruir", 20, 40);
	ofDrawBitmapStringHighlight("Estado Actual: " + currentState->getName(), 20, 60);
	ofDrawBitmapStringHighlight("Esta Temblando?: " + std::string(shaking ? "si" : "no"), 20, 80);
}

void ofApp::keyPressed(int key) {
	if (key == '1')
		changeState(std::make_shared<BuildingState>(&buildings, &cars, this,
			ofColor(100, 100, 255), ofColor(180, 0, 255), 0.2, 0, "calma"));
	else if (key == '2')
		changeState(std::make_shared<BuildingState>(&buildings, &cars, this,
			ofColor(255, 180, 0), ofColor(255, 100, 0), 1.0, 20, "ay mano"));
	else if (key == '3')
		changeState(std::make_shared<BuildingState>(&buildings, &cars, this,
			ofColor(255, 50, 0), ofColor(150, 0, 0), 2.5, 5, "TERREMOTOOOOO!!!"));
	else if (key == 's')
		shaking = true, stateStartTime = ofGetElapsedTimef();
	else if (key == 'p')
		shaking = false;
	else if (key == ' ') {
		notify("reconstruir");
		shaking = false;
		for (auto & b : buildings)
			b->onNotify("reconstruir");
		for (auto & c : cars)
			c->onNotify("reconstruir");
		currentState->enter();
		stateStartTime = ofGetElapsedTimef();
	}
}

void ofApp::changeState(std::shared_ptr<State> newState) {
	currentState = std::move(newState);
	currentState->enter();
	stateStartTime = ofGetElapsedTimef();
}
