#pragma once
#include "Particulas.h"

class ParticleTransient : public Particle {
private:
	float lifetime;
	float age;

public:
	ParticleTransient(ofVec2f pos)
		: Particle(pos) {
		lifetime = 2.0;
		age = 0.0;
	}

	void update(float dt) override {
		age += dt;
		float t = age / lifetime;
		size = ofLerp(size, size * 3, t);
		color.a = ofLerp(255, 0, t);
		if (age >= lifetime) {
			alive = false;
		}
	}

	void draw() override {
		ofSetColor(color);
		if (shapeType == 0)
			ofDrawCircle(position, size);
		else if (shapeType == 1)
			ofDrawRectangle(position.x - size / 2, position.y - size / 2, size, size);
		else
			ofDrawTriangle(position.x, position.y - size,
				position.x - size, position.y + size,
				position.x + size, position.y + size);
	}
};
