#pragma once
#include "Particulas.h"

class ParticleBounce : public Particle {
private:
    ofVec2f velocity;
    float lifetime;
    float age;

public:
    ParticleBounce(ofVec2f pos) : Particle(pos) {
        velocity.set(ofRandom(-5, 5), ofRandom(-5, 5)); 
        size = ofRandom(3, 8);
        lifetime = 3.0;
        age = 0.0;
    }

    void update(float dt) override {
        age += dt;
        position += velocity;

        if (position.x <= 0 || position.x >= ofGetWidth()) {
            velocity.x *= -1;
        }
        if (position.y <= 0 || position.y >= ofGetHeight()) {
            velocity.y *= -1;
        }

        color.a = ofLerp(255, 0, age / lifetime);

        if (age >= lifetime) {
            alive = false;
        }
    }

    void draw() override {
        ofSetColor(color);
        ofDrawCircle(position, size);
    }
};
