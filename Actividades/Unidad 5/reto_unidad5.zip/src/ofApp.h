#pragma once

#include "Particulas.h"
#include "Expande.h"
#include "Permanente.h"
#include "ofMain.h"

class ofApp : public ofBaseApp {
public:
	vector<Particle *> particles;
	ofVec2f mouseBall;

	void setup();
	void update();
	void draw();
	void keyPressed(int key);

	void exit(); 
};
