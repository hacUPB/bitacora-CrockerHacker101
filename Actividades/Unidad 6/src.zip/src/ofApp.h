#pragma once
#include "ofMain.h"
#include <algorithm>
#include <cmath>
#include <memory>
#include <string>
#include <vector>

// ---------- OBSERVER ----------
class Observer {
public:
	virtual void onNotify(const std::string & event) = 0;
};

// ---------- SUBJECT ----------
class Subject {
public:
	void addObserver(Observer * obs) { observers.push_back(obs); }
	void notify(const std::string & event) {
		for (auto obs : observers)
			obs->onNotify(event);
	}

private:
	std::vector<Observer *> observers;
};

// ---------- PARTICLE ----------
class Particle {
public:
	ofVec2f pos, vel;
	float size;
	ofColor color;
	bool dead = false;

	Particle(const ofVec2f & p, const ofColor & c)
		: pos(p)
		, vel(ofRandom(-2, 2), ofRandom(-8, -3))
		, size(ofRandom(2, 5))
		, color(c) { }

	void update() {
		vel.y += 0.4; // gravedad
		pos += vel;

		// detener al tocar el suelo
		if (pos.y > ofGetHeight() - size) {
			pos.y = ofGetHeight() - size;
			vel.set(0, 0);
			color.a = std::max(0, color.a - 4);
			if (color.a == 0) dead = true;
		}
	}

	void draw() const {
		ofSetColor(color);
		ofDrawRectangle(pos.x, pos.y, size, size);
	}
};

// ---------- BUILDING ----------
class Building : public Observer {
public:
	ofVec2f pos;
	float width, height;
	ofColor color;
	bool fallen = false;
	float baseX;
	std::vector<Particle> debris;

	Building(ofVec2f p, float w, float h, const ofColor & c)
		: pos(p)
		, width(w)
		, height(h)
		, color(c)
		, baseX(p.x) { }

	void onNotify(const std::string & event) override {
		if (event == "collapse" && !fallen) {
			fallen = true;
			debris.reserve(120);
			for (int i = 0; i < ofRandom(60, 120); ++i) {
				debris.emplace_back(ofVec2f(pos.x + ofRandom(width), pos.y - ofRandom(height)), color);
			}
		} else if (event == "reset" || event == "reconstruir") {
			fallen = false;
			debris.clear();
			pos.x = baseX;
		}
	}

	void update() {
		for (auto & p : debris)
			p.update();
		debris.erase(std::remove_if(debris.begin(), debris.end(),
						 [](const Particle & p) { return p.dead; }),
			debris.end());
	}

	void draw() const {
		if (!fallen) {
			ofSetColor(color);
			ofDrawRectangle(pos.x, pos.y - height, width, height);
		} else {
			for (const auto & p : debris)
				p.draw();
		}
	}
};

// ---------- BUILDING FACTORY ----------
class BuildingFactory {
public:
	static std::shared_ptr<Building> createBuilding(const ofVec2f & pos, float w, float h, const ofColor & c) {
		return std::make_shared<Building>(pos, w, h, c);
	}
};

// ---------- CAR ----------
class Car : public Observer {
public:
	ofVec2f pos;
	float radius;
	ofColor color;
	float baseY;
	bool crushed = false;
	float scaleY = 1.0f;

	Car(ofVec2f p, float r, const ofColor & c)
		: pos(p)
		, radius(r)
		, color(c)
		, baseY(p.y) { }

	void onNotify(const std::string & event) override {
		if (event == "collapse" && !crushed) {
			crushed = true; // aplastar cuando colapsa
		} else if (event == "reconstruir") {
			crushed = false;
			scaleY = 1.0f;
			pos.y = baseY;
		}
	}

	void update() {
		// No modificamos scaleY aqu�. Lo hace el estado seg�n crushed y estado.
	}

	void draw() const {
		ofPushMatrix();
		ofTranslate(pos.x, pos.y);
		ofScale(1.0f, scaleY);
		ofSetColor(color);
		ofDrawCircle(0, 0, radius);
		ofPopMatrix();
	}
};

// ---------- CAR FACTORY ----------
class CarFactory {
public:
	static std::shared_ptr<Car> createCar(const ofVec2f & pos, float r, const ofColor & c) {
		return std::make_shared<Car>(pos, r, c);
	}
};

// ---------- STATE BASE ----------
class State {
public:
	virtual void enter() = 0;
	virtual void update(float elapsedTime, bool shaking) = 0;
	virtual void draw() = 0;
	virtual void exit() { }
	virtual std::string getName() const = 0;
	virtual float getCollapseTime() const = 0;
	virtual ~State() = default;
};

// ---------- APP ----------
class ofApp : public ofBaseApp, public Subject {
public:
	void setup() override;
	void update() override;
	void draw() override;
	void keyPressed(int key) override;

private:
	void changeState(std::shared_ptr<State> newState);
	void createBuildings();
	void createCars();

	std::vector<std::shared_ptr<Building>> buildings;
	std::vector<std::shared_ptr<Car>> cars;
	std::shared_ptr<State> currentState;
	float stateStartTime = 0;
	bool shaking = false;
};
